void normal_01_cdf_values(int *n_data, double *x, double *fx);
float r4_huge(void);
float r4_normal_01_cdf_inverse(float p);
float r4poly_value(int n, float a[], float x);
double r8_huge(void);
double r8_normal_01_cdf_inverse(double p);
double r8poly_value(int n, double a[], double x);
void timestamp(void);