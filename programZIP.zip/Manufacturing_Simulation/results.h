#include "inv_tran_sampling.h"

int comparator(const void*, const void*);
void printHistogram(process, int);
void printResult(int, process[], int);
void printSortedResult(int, process[], int);
void printOverallResult(int, process[], int);